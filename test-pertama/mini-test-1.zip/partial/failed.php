<div class="alert alert-warning" role="alert">
  Oops jumlah looping kurang dari 100
</div>

<script type="text/javascript">
	Swal.fire({
		icon: 'info',
		title: 'Oops...',
		text: 'Minimal jumlah looping 100 atau lebih dari'
	})
</script>