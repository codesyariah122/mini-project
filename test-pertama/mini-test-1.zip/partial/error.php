<div class="alert alert-danger" role="alert">
  Oops silahkan input jumlah looping terlebih dahulu
</div>

<script type="text/javascript">
	Swal.fire({
		icon: 'error',
		title: 'Oops...',
		text: 'Anda belum menginput jumlah looping!'
	})
</script>