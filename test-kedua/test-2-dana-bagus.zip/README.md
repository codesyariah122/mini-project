### Test kedua
#### Setup  

- extract zip ```mini-test-2``` 
- access di terminal / CMD  
```
cd mini-test-2/
# initialisasi package **Jalankan perintah berikut :**
yarn  

# runing development **Jalankan perintah berikut :**
yarn start
```  

- open web browser (chrome, firefox)  
- access url :  http://localhost:5000/